import { BASE_POSITIONS, HOME_ENTRANCE, HOME_POSITIONS, PLAYERS, SAFE_POSITIONS, START_POSITIONS, STATE, TURNING_POINTS } from './constants.js';
import { UI } from './UI.js';

export class Ludo {
    currentPositions = {
        P1: [],
        P2: []
    };

    yourPlayer = '';  // To store the player role (P1 or P2)
    opponentValue = {}
    _diceValue;
    get diceValue() {
        return this._diceValue;
    }
    set diceValue(value) {
        this._diceValue = value;
        UI.setDiceValue(value);
    }

    _turn;
    get turn() {
        return this._turn;
    }
    set turn(value) {
        this._turn = value;
        UI.setTurn(value);
    }

    _state;
    get state() {
        return this._state;
    }
    set state(value) {
        this._state = value;
        if (value === STATE.DICE_NOT_ROLLED) {
            UI.enableDice();
            UI.unhighlightPieces();
        } else {
            UI.disableDice();
        }
    }

    constructor() {
        console.log('Hello World! Let\'s play Ludo!');

        this.listenDiceClick();
        this.listenResetClick();
        this.listenPieceClick();

        this.resetGame();
        this.connectWebSocket();
    }

    listenDiceClick() {
        UI.listenDiceClick(this.onDiceClick.bind(this));
    }

    onDiceClick() {
       
        if (this.yourPlayer !== `P${this.turn + 1}`) {
            console.log(`${this.yourPlayer} == P${this.turn+1}`)
            console.log('It is not your turn to roll the dice.');
            return;
        }
        
        console.log('Dice clicked!');
        this.diceValue = 1 + Math.floor(Math.random() * 6);
        this.state = STATE.DICE_ROLLED;
        
        this.checkForEligiblePieces();
        ////////////
        if (this.yourPlayer !== `P${this.turn + 1}`) {
           this.sendDataDiceTurn(this.diceValue, `P${this.turn + 1}`)
        }

    }

    checkForEligiblePieces() {
        const player = PLAYERS[this.turn];
        const eligiblePieces = this.getEligiblePieces(player);
        if (eligiblePieces.length) {
            UI.highlightPieces(player, eligiblePieces);
        } else {
            this.incrementTurn();
        }
    }

    incrementTurn() {
        this.turn = this.turn === 0 ? 1 : 0;
        this.state = STATE.DICE_NOT_ROLLED;
    }

    getEligiblePieces(player) {
        return [0, 1, 2, 3].filter(piece => {
            const currentPosition = this.currentPositions[player][piece];
            if (currentPosition === HOME_POSITIONS[player]) {
                return false;
            }
            if (BASE_POSITIONS[player].includes(currentPosition) && this.diceValue !== 6) {
                return false;
            }
            if (HOME_ENTRANCE[player].includes(currentPosition) && this.diceValue > HOME_POSITIONS[player] - currentPosition) {
                return false;
            }
            return true;
        });
    }

    listenResetClick() {
        UI.listenResetClick(this.resetGame.bind(this));
    }

    resetGame() {
        console.log('Reset game');
        this.currentPositions = structuredClone(BASE_POSITIONS);

        PLAYERS.forEach(player => {
            [0, 1, 2, 3].forEach(piece => {
                this.setPiecePosition(player, piece, this.currentPositions[player][piece]);
            });
        });

        this.turn = 0;
        this.state = STATE.DICE_NOT_ROLLED;
    }

    listenPieceClick() {
        UI.listenPieceClick(this.onPieceClick.bind(this));
    }

    onPieceClick(event) {
        const target = event.target;
        if (!target.classList.contains('player-piece') || !target.classList.contains('highlight')) {
            return;
        }

        // Only allow the player with the correct role to move pieces
        if (this.yourPlayer !== `P${this.turn + 1}`) {
            console.log('It is not your turn to move a piece.');
            return;
        }

        console.log('Piece clicked');
        const player = target.getAttribute('player-id');
        const piece = target.getAttribute('piece');
        this.handlePieceClick(player, piece);
    }

    handlePieceClick(player, piece) {
        console.log(player, piece);
        const currentPosition = this.currentPositions[player][piece];
        
        if (BASE_POSITIONS[player].includes(currentPosition)) {
            this.setPiecePosition(player, piece, START_POSITIONS[player]);
            this.state = STATE.DICE_NOT_ROLLED;
            return;
        }

        UI.unhighlightPieces();
        this.movePiece(player, piece, this.diceValue);
    }

    setPiecePosition(player, piece, newPosition) {
        this.currentPositions[player][piece] = newPosition;
        UI.setPiecePosition(player, piece, newPosition);
    }

    movePiece(player, piece, moveBy) {
        const interval = setInterval(() => {
            this.incrementPiecePosition(player, piece);
            moveBy--;
    
            if (moveBy === 0) {
                clearInterval(interval);
    
                if (this.hasPlayerWon(player)) {
                    alert(`Player: ${player} has won!`);
                    this.resetGame();
                    return;
                }
    
                const isKill = this.checkForKill(player, piece);
    
                if (isKill || this.diceValue === 6) {
                    this.state = STATE.DICE_NOT_ROLLED;
                    // Send game data to server after the move
                    this.sendGameData(piece, this.diceValue, this.currentPositions, this.turn);
                    return;
                }
    
                this.incrementTurn();
                
                // Send game data to server after the turn has been incremented
                this.sendGameData(piece, this.diceValue, this.currentPositions, this.turn);
            }
        }, 200);
    }
    

    checkForKill(player, piece) {
        const currentPosition = this.currentPositions[player][piece];
        const opponent = player === 'P1' ? 'P2' : 'P1';
        let kill = false;

        [0, 1, 2, 3].forEach(opponentPiece => {
            const opponentPosition = this.currentPositions[opponent][opponentPiece];
            if (currentPosition === opponentPosition && !SAFE_POSITIONS.includes(currentPosition)) {
                this.setPiecePosition(opponent, opponentPiece, BASE_POSITIONS[opponent][opponentPiece]);
                kill = true;
            }
        });

        return kill;
    }

    hasPlayerWon(player) {
        return [0, 1, 2, 3].every(piece => this.currentPositions[player][piece] === HOME_POSITIONS[player]);
    }

    incrementPiecePosition(player, piece) {
        this.setPiecePosition(player, piece, this.getIncrementedPosition(player, piece));
    }
    
    getIncrementedPosition(player, piece) {
        const currentPosition = this.currentPositions[player][piece];

        if (currentPosition === TURNING_POINTS[player]) {
            return HOME_ENTRANCE[player][0];
        } else if (currentPosition === 51) {
            return 0;
        }
        return currentPosition + 1;
    }

    // WebSocket Integration
    connectWebSocket() {
        this.socket = new WebSocket('ws://127.0.0.1:8080/find-opponent/674203a728a4cbd5751b9757/673f69d99cb56bd01780bf95');

        this.socket.onopen = () => {
            console.log('WebSocket connection established');
        };

        this.socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            console.log('Received WebSocket message:', data);

            if (data.message === 'game data' && data.data_received) {
                
                if(data.data_received.message === "next turn"){
                   this.turn = data.data_received.turn;
                   this.diceValue = data.data_received.diceValue;
                }else{
                    this.handleGameData(data.data_received);
                }
            }else{
                this.yourPlayer = data.your_player;
            }
        };  

        this.socket.onclose = () => {
            console.log('WebSocket connection closed');
        };
    }

    handleGameData(dataReceived) {
        this.currentPositions = dataReceived.currentPosition;
        this.diceValue = dataReceived.diceValue;
        this.turn = dataReceived.nextTurn;
        this.piece = dataReceived.piece;
        const yourPlayer = dataReceived.your_player;
        console.log('You are playing as:', yourPlayer);

        // Set the role for your player (P1 or P2)
        this.yourPlayer = yourPlayer;

        // Optionally, set up the UI or handle opponent data
        if (dataReceived.opponent_data) {
            console.log('Opponent data:', dataReceived.opponent_data);
        }
    }

    // Method to send game data via WebSocket
    sendGameData(piece, diceValue, currentPosition, nextTurn) {
        console.log("data sensd");
        const dataToSend = {
            message: 'move',
            piece: piece,
            diceValue: diceValue,
            currentPosition: currentPosition,
            nextTurn: nextTurn
        };
        console.log("Sended data");
        console.log(dataToSend);
    
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(dataToSend));
        } else {
            console.error('WebSocket is not open.');
        }
    }
    sendDataDiceTurn( diceValue, nextTurn) {
        console.log("data sensd");
        const dataToSend = {
            message: 'next turn',
            diceValue: diceValue,
            nextTurn: nextTurn
        };
        console.log("Sended data");
        console.log(dataToSend);
    
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(dataToSend));
        } else {
            console.error('WebSocket is not open.');
        }
    }
}
