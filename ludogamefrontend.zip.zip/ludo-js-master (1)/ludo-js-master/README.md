# Ludo Game in Vanilla JavaScript 🚀

![javascript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) ![html](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) ![css](https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white)

#### Demo: https://ludo-js.web.app/
#### Tutorial: https://youtu.be/2dgYLR2hOTk

![ludo](https://github.com/sohail-js/ludo-js/blob/master/ludo/ludo-bg.jpg?raw=true)
