USER_DB = {
    "testuser": {"username": "testuser", "password": "testpassword"}
}