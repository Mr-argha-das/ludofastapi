import { Ludo } from './ludologic/Ludo.js';

const ludo = new Ludo();