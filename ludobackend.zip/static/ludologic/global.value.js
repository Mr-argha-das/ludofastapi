var myGlobalVariable = null;


// const socket = new WebSocket('ws://your-websocket-server-url');

// socket.onopen = (event) => {
//   console.log('WebSocket connection established.');
  
//   // Optionally, you can send a message to the server
//   socket.send(JSON.stringify({ message: 'Hello server!' }));
// };

// socket.onmessage = (event) => {
//   // Assuming the response is in JSON format
//   try {
//     const jsonResponse = JSON.parse(event.data);
//     console.log('Received JSON response:', jsonResponse);
    
//     // Handle the response data
//   } catch (error) {
//     console.error('Error parsing JSON response:', error);
//   }

// };

// socket.onerror = (error) => {
//   console.error('WebSocket error:', error);
// };

// socket.onclose = () => {
//   console.log('WebSocket connection closed.');
// };

function initializeWebSocket(userid, priceid) {
    const socket = new WebSocket(`ws://127.0.0.1:8080/find-opponent/674203a728a4cbd5751b9757/673f69d99cb56bd01780bf95`);
    const loader = document.getElementById('loader');
    let idleTimer = null;
    const idleTimeLimit = 5000; // Time limit in milliseconds (e.g., 5 seconds)
  
    // Function to show the loader
    function showLoader() {
      loader.style.display = 'block';
    }
  
    // Function to hide the loader
    function hideLoader() {
      loader.style.display = 'none';
    }
  
    // Function to reset the idle timer
    function resetIdleTimer() {
      clearTimeout(idleTimer);
      hideLoader(); // Hide the loader if any data is received
  
      // Start the idle timer again
      idleTimer = setTimeout(() => {
        showLoader(); // Show loader if no data received in the time limit
      }, idleTimeLimit);
    }
  
    // WebSocket event listeners
    socket.onopen = () => {
      console.log('WebSocket connection established.');
      hideLoader(); // Start the idle timer when connection opens
    };
  
    socket.onmessage = (event) => {
      console.log('Message received:', event.data);
  
      // Reset the timer as we're receiving data
      hideLoader();
  
      // Parse and handle the message if it's in JSON format
      try {
        const jsonResponse = JSON.parse(event.data);
        console.log('Received JSON response:', jsonResponse);
        myGlobalVariable = jsonResponse["your_player"]
        // Handle the JSON response here
      } catch (error) {
        console.error('Error parsing JSON response:', error);
      }
    };
  
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      hideLoader(); // Hide loader if there's an error
    };
  
    socket.onclose = () => {
      console.log('WebSocket connection closed.');
      hideLoader(); // Hide loader when connection closes
    };
  
    // Initially show the loader after the connection opens
    showLoader();
  }
  
  // When the page is loaded, initiate the WebSocket connection


  window.onload = () => {
    initializeWebSocket("674203a728a4cbd5751b9757", "673f69d99cb56bd01780bf95");
};