from fastapi import APIRouter, Request, Depends, HTTPException
from authlib.integrations.starlette_client import OAuth
from starlette.config import Config
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.requests import Request
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import json
from login.model.login_model import LoginBody, LoginTable
from starlette.middleware.sessions import SessionMiddleware
from dotenv import load_dotenv
from wallet.wallet_model import WalletModel, WalletTable
from bson import ObjectId
import firebase_admin
from firebase_admin import credentials, auth
from firebase_admin import auth
import random
import pyotp 
from twilio.rest import Client
# Initialize Firebase Admin SDK with the service account credentials
cred = credentials.Certificate("firebase/ludo-754ab-firebase-adminsdk-7oyeb-8a6bb24a75.json")
firebase_admin.initialize_app(cred)

load_dotenv()

router = APIRouter()

class LoginBodyLogin(BaseModel):
    email : str
    password: str


# OAuth Configuration
config = Config(".env")  # Create a .env file with CLIENT_ID and CLIENT_SECRET
oauth = OAuth(config)
oauth.register(
    name="google",
    client_id=config("GOOGLE_CLIENT_ID"),
    client_secret=config("GOOGLE_CLIENT_SECRET"),
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

@router.post("/api/user/create")
async def create_user(request: Request, body: LoginBody):
    phone = request.session.get("phonenumber")
    findata = LoginTable.objects(email=phone["number"]).first()
    if findata:
        return {
            "message": "user already exist",
            "data": None,
            "status": False
        }
    else:
        saveData = LoginTable(email=phone["number"], name=body.name, password=phone["number"])
        saveData.save()
        wallet = WalletTable(userid=str(ObjectId(saveData.id)), balance=49, totalWithdrawal=0)
        wallet.save()
        walletJson = wallet.to_json()
        walletFromjson = json.loads(walletJson)
        tojson = saveData.to_json()
        fromjson = json.loads(tojson)
        request.session["user"] = {
                "data":fromjson,
            }
        request.session["wallet"] = {
            "balance":walletFromjson,
            }
        return {
            "message": "User Created Succes",
            "data": fromjson,
            "status": True
        }




@router.get("/api/user/get-users")
async def get_User():
    findata = LoginTable.objects.all()
    tojson = findata.to_json()
    fromjson = json.loads(tojson)
    return {
        "message": "Here is all users",
        "data": fromjson,
        "status": True
    }

@router.post("/api/user/login")
async def login_user(request: Request, body: LoginBodyLogin):
    findUser = LoginTable.objects(email=body.email).first()
    if findUser:
        if findUser.password == body.password:
            tojson = findUser.to_json()
            fromjson = json.loads(tojson)
            request.session["user"] = {
                "data":fromjson,
            }
            wallet = WalletTable.objects(userid=str(ObjectId(findUser.id))).first()
            walletTojson = wallet.to_json()
            walletFromJson = json.loads(walletTojson)
            request.session["wallet"] = {
            "balance":walletFromJson,
            }
            return {
                "message": "User Login Suces",
                "data":fromjson,
                "status": True
            }
        else:
            return {
                "message": "User password Inccorect",
                "data": None,
                "status": False
            }
    else:
        return {
                "message": "User not found",
                "data": None,
                "status": False
            }

@router.get("/auth/google")
async def google_login(request: Request):
    redirect_uri = request.url_for("auth")  # The callback URL
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/auth/callback")
async def auth(request: Request):
    token = await oauth.google.authorize_access_token(request)
    user = token.get("userinfo")  # Get user info
    email = user["email"]
    finduser = LoginTable.objects(email=email).first()
    print(user)
    print(finduser)
    if finduser:
        # You can store user info in your database here
        tojson = finduser.to_json()
        fromjson = json.loads(tojson)
        request.session["user"] = {     
            "data":fromjson,
        }
        return RedirectResponse(url="/home")
    else:
        saveUserData = LoginTable(email=user['email'], name=user['name'], password=user['nonce'])
        saveUserData.save()
        print(ObjectId(saveUserData.id))
        wallet = WalletTable(userid=str(ObjectId(saveUserData.id)), balance=49, totalWithdrawal=0)
        wallet.save()
        walletJson = wallet.to_json()
        walletFromjson = json.loads(walletJson)
        tojson = saveUserData.to_json()
        fromjson = json.loads(tojson)
        request.session["user"] = {
            "data":fromjson,
        }
        request.session["wallet"] = {
            "balance":walletFromjson,
        }
        return RedirectResponse(url="/home")
    return {"error": "Unable to authenticate user"}

otp_storage = {}

# Define Pydantic models for requests
class OTPRequest(BaseModel):
    phone_number: str

class OTPVerifyRequest(BaseModel):
    otp: str

@router.post("/send-otp/")
async def send_otp(request: Request, body: OTPRequest):
    phone_number = body.phone_number
    otp = str(random.randint(100000, 999999))  # Generate 6 digit OTP

    # Save OTP temporarily
    otp_storage[phone_number] = otp
    account_sid = 'AC68d3bdc009b153d3e6c29eaa029799a6'
    auth_token = '9dd8e039e41cd8b8d205b5e0d0ec257a'
    client = Client(account_sid, auth_token)

    message = client.messages.create(
                from_='+15744440027',
                body=f'Your Ludo Buddy login code {otp}',
                to=f'+{phone_number}'
                )
    print(message.sid)
    # Here you can integrate with an SMS gateway like Twilio or Firebase to send OTP to user
    request.session["phonenumber"] = {
       "number": phone_number
    }
    print(phone_number)
    return {"message": "OTP sent", "otp": otp}  # In practice, don’t return OTP in response!

@router.post("/verify-otp/")
async def verify_otp(request: Request, body: OTPVerifyRequest):
    phone_number= request.session.get("phonenumber")
    print(phone_number)
    otp = body.otp

    # Check if OTP is valid
    stored_otp = otp_storage.get(phone_number["number"])

    if stored_otp == otp:
        findUser = LoginTable.objects(email=phone_number["number"]).first()
        if findUser:
            tojson = findUser.to_json()
            fromjson = json.loads(tojson)
            request.session["user"] = {
                "data":fromjson,
            }
            wallet = WalletTable.objects(userid=str(ObjectId(findUser.id))).first()
            walletTojson = wallet.to_json()
            walletFromJson = json.loads(walletTojson)
            request.session["wallet"] = {
            "balance":walletFromJson,
            }
            return {
                "message": "User Login Suces",
                "data":fromjson,
                "status": True
            }
        else:
             return {
                "message": "You dont have account register first",
                "data": None,
                "status": False
            }
    else:
        return {
                "message": "otp Incorrect",
                "data": None,
                "status": False
            }
